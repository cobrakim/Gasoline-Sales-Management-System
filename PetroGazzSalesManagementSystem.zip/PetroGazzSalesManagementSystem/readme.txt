Download latest XAMPP

**LOGIN DETAILS** 

admin
user: admin
pass: admin

user
user: test
pass: test
